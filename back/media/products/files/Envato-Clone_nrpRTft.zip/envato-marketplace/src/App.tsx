import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './redux/store';
import Layout from './components/layout/Layout';
import HomePage from './components/pages/HomePage';
import ProductDetailsPage from './components/pages/ProductDetailsPage';
import CategoryPage from './components/pages/CategoryPage';

// Import bootstrap CSS in the main component
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <Provider store={store}>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/product/:id" element={<ProductDetailsPage />} />
            <Route path="/category/:category" element={<CategoryPage />} />
            {/* More routes will be added here */}
            <Route path="*" element={<div className="text-center py-5"><h2>Page Not Found</h2></div>} />
          </Routes>
        </Layout>
      </Router>
    </Provider>
  );
}

export default App;
