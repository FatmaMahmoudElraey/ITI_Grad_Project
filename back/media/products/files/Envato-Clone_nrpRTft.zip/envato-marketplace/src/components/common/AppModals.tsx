import type React from 'react';
import { useSelector } from 'react-redux';
import type { RootState } from '../../redux/store';
import CartModal from './CartModal';
import LoginModal from './LoginModal';

const AppModals: React.FC = () => {
  const { modal } = useSelector((state: RootState) => state.ui);

  return (
    <>
      {/* Cart Modal */}
      <CartModal />

      {/* Login/Register Modal */}
      <LoginModal />

      {/* Add more modals as needed */}
    </>
  );
};

export default AppModals;
