import type React from 'react';
import { Modal, Button, ListGroup, Row, Col, Form } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faShoppingBag } from '@fortawesome/free-solid-svg-icons';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../../redux/store';
import { closeModal } from '../../redux/reducers/uiSlice';
import { removeFromCart, updateQuantity, clearCart } from '../../redux/reducers/cartSlice';
import { Link } from 'react-router-dom';

const CartModal: React.FC = () => {
  const dispatch = useDispatch();
  const { modal } = useSelector((state: RootState) => state.ui);
  const { items, totalItems, totalAmount } = useSelector((state: RootState) => state.cart);

  const handleClose = () => {
    dispatch(closeModal());
  };

  const handleRemoveItem = (id: string) => {
    dispatch(removeFromCart(id));
  };

  const handleQuantityChange = (id: string, quantity: number) => {
    dispatch(updateQuantity({ id, quantity }));
  };

  const handleClearCart = () => {
    dispatch(clearCart());
  };

  return (
    <Modal show={modal.isOpen && modal.type === 'cart'} onHide={handleClose} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>
          <FontAwesomeIcon icon={faShoppingBag} className="me-2" />
          Your Cart ({totalItems} items)
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {items.length > 0 ? (
          <>
            <ListGroup variant="flush">
              {items.map((item) => (
                <ListGroup.Item key={item.id} className="py-3">
                  <Row className="align-items-center">
                    <Col xs={3} md={2}>
                      <img
                        src={item.image}
                        alt={item.title}
                        className="img-fluid rounded"
                        style={{ maxHeight: '60px', objectFit: 'cover' }}
                      />
                    </Col>
                    <Col xs={6} md={7}>
                      <h6 className="mb-1">{item.title}</h6>
                      <small className="text-muted">by {item.author}</small>
                      <div className="d-flex align-items-center mt-2">
                        <Form.Label className="me-2 mb-0">Qty:</Form.Label>
                        <Form.Select
                          size="sm"
                          style={{ width: '70px' }}
                          value={item.quantity}
                          onChange={(e) =>
                            handleQuantityChange(item.id, Number.parseInt(e.target.value, 10))
                          }
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                            <option key={num} value={num}>
                              {num}
                            </option>
                          ))}
                        </Form.Select>
                      </div>
                    </Col>
                    <Col xs={3} className="text-end">
                      <div className="fw-bold mb-2">${(item.price * item.quantity).toFixed(2)}</div>
                      <Button
                        variant="link"
                        className="text-danger p-0"
                        onClick={() => handleRemoveItem(item.id)}
                      >
                        <FontAwesomeIcon icon={faTrash} /> Remove
                      </Button>
                    </Col>
                  </Row>
                </ListGroup.Item>
              ))}
            </ListGroup>

            <div className="d-flex justify-content-between align-items-center mt-4 mb-3">
              <Button variant="outline-secondary" size="sm" onClick={handleClearCart}>
                Clear Cart
              </Button>
              <div className="text-end">
                <div className="text-muted mb-1">Subtotal:</div>
                <div className="fs-4 fw-bold">${totalAmount.toFixed(2)}</div>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-5">
            <h5 className="mb-3">Your cart is empty</h5>
            <p className="text-muted mb-4">
              Browse our collection of high-quality digital assets and add them to your cart.
            </p>
            <Button variant="envato" onClick={handleClose}>
              Start Shopping
            </Button>
          </div>
        )}
      </Modal.Body>
      {items.length > 0 && (
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Continue Shopping
          </Button>
          <Link to="/checkout" className="btn btn-envato" onClick={handleClose}>
            Proceed to Checkout
          </Link>
        </Modal.Footer>
      )}
    </Modal>
  );
};

export default CartModal;
