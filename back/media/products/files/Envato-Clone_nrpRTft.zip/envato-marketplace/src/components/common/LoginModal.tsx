import type React from 'react';
import { useState } from 'react';
import { Modal, Button, Form, Tabs, Tab, Alert } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faEnvelope, faLock, faSignInAlt, faUserPlus } from '@fortawesome/free-solid-svg-icons';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../../redux/store';
import { closeModal, openModal } from '../../redux/reducers/uiSlice';
import { loginStart, loginSuccess, loginFailure } from '../../redux/reducers/authSlice';

// Mock user data for demo purposes
const mockUsers = [
  {
    id: 'user1',
    name: 'John Doe',
    email: 'john@example.com',
    password: 'password123',
    avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
    role: 'user' as const,
  },
  {
    id: 'user2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    password: 'password123',
    avatar: 'https://randomuser.me/api/portraits/women/1.jpg',
    role: 'author' as const,
  },
];

const LoginModal: React.FC = () => {
  const dispatch = useDispatch();
  const { modal } = useSelector((state: RootState) => state.ui);
  const { loading, error } = useSelector((state: RootState) => state.auth);

  const [activeTab, setActiveTab] = useState<'login' | 'register'>(
    modal.type === 'register' ? 'register' : 'login'
  );
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [registerConfirmPassword, setRegisterConfirmPassword] = useState('');
  const [registerError, setRegisterError] = useState<string | null>(null);

  const handleClose = () => {
    dispatch(closeModal());
  };

  const handleTabChange = (tab: string | null) => {
    if (tab === 'login' || tab === 'register') {
      setActiveTab(tab);

      // Update the modal type in Redux
      dispatch(openModal({ type: tab }));
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch(loginStart());

    // Simulate API call
    setTimeout(() => {
      const user = mockUsers.find(
        (u) => u.email === loginEmail && u.password === loginPassword
      );

      if (user) {
        // Remove password before storing user data
        const { password, ...userWithoutPassword } = user;
        dispatch(loginSuccess(userWithoutPassword));
        dispatch(closeModal());
      } else {
        dispatch(loginFailure('Invalid email or password'));
      }
    }, 1000);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegisterError(null);

    // Validate form
    if (!registerName || !registerEmail || !registerPassword || !registerConfirmPassword) {
      setRegisterError('All fields are required');
      return;
    }

    if (registerPassword !== registerConfirmPassword) {
      setRegisterError('Passwords do not match');
      return;
    }

    // Check if email is already registered
    if (mockUsers.some((user) => user.email === registerEmail)) {
      setRegisterError('Email is already registered');
      return;
    }

    // In a real app, this would make an API call to register the user
    alert('Registration successful! Please login with your new account.');
    setActiveTab('login');
    setLoginEmail(registerEmail);
    setLoginPassword('');
  };

  return (
    <Modal
      show={modal.isOpen && (modal.type === 'login' || modal.type === 'register')}
      onHide={handleClose}
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>
          {activeTab === 'login' ? (
            <>
              <FontAwesomeIcon icon={faSignInAlt} className="me-2" />
              Sign In
            </>
          ) : (
            <>
              <FontAwesomeIcon icon={faUserPlus} className="me-2" />
              Create Account
            </>
          )}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Tabs
          activeKey={activeTab}
          onSelect={handleTabChange}
          id="auth-tabs"
          className="mb-4"
        >
          <Tab eventKey="login" title="Login">
            {error && <Alert variant="danger">{error}</Alert>}
            <Form onSubmit={handleLogin}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <FontAwesomeIcon icon={faEnvelope} className="me-2" />
                  Email Address
                </Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  required
                />
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label>
                  <FontAwesomeIcon icon={faLock} className="me-2" />
                  Password
                </Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  required
                />
                <div className="mt-2 text-end">
                  <a href="/forgot-password" className="text-decoration-none small">
                    Forgot Password?
                  </a>
                </div>
              </Form.Group>

              <Button
                variant="envato"
                type="submit"
                className="w-100 py-2"
                disabled={loading}
              >
                {loading ? 'Signing in...' : 'Sign In'}
              </Button>

              <div className="text-center mt-4">
                <p className="text-muted">
                  Don't have an account?{' '}
                  <Button
                    variant="link"
                    className="p-0"
                    onClick={() => handleTabChange('register')}
                  >
                    Create one now
                  </Button>
                </p>
              </div>
            </Form>
          </Tab>
          <Tab eventKey="register" title="Register">
            {registerError && <Alert variant="danger">{registerError}</Alert>}
            <Form onSubmit={handleRegister}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <FontAwesomeIcon icon={faUser} className="me-2" />
                  Full Name
                </Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Your name"
                  value={registerName}
                  onChange={(e) => setRegisterName(e.target.value)}
                  required
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>
                  <FontAwesomeIcon icon={faEnvelope} className="me-2" />
                  Email Address
                </Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                  value={registerEmail}
                  onChange={(e) => setRegisterEmail(e.target.value)}
                  required
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>
                  <FontAwesomeIcon icon={faLock} className="me-2" />
                  Password
                </Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Password"
                  value={registerPassword}
                  onChange={(e) => setRegisterPassword(e.target.value)}
                  required
                />
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Label>
                  <FontAwesomeIcon icon={faLock} className="me-2" />
                  Confirm Password
                </Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Confirm password"
                  value={registerConfirmPassword}
                  onChange={(e) => setRegisterConfirmPassword(e.target.value)}
                  required
                />
              </Form.Group>

              <Form.Group className="mb-4">
                <Form.Check
                  type="checkbox"
                  id="terms-check"
                  label={
                    <span>
                      I agree to the{' '}
                      <a href="/terms" className="text-decoration-none">
                        Terms of Service
                      </a>{' '}
                      and{' '}
                      <a href="/privacy" className="text-decoration-none">
                        Privacy Policy
                      </a>
                    </span>
                  }
                  required
                />
              </Form.Group>

              <Button variant="envato" type="submit" className="w-100 py-2">
                Create Account
              </Button>

              <div className="text-center mt-4">
                <p className="text-muted">
                  Already have an account?{' '}
                  <Button
                    variant="link"
                    className="p-0"
                    onClick={() => handleTabChange('login')}
                  >
                    Sign in
                  </Button>
                </p>
              </div>
            </Form>
          </Tab>
        </Tabs>
      </Modal.Body>
    </Modal>
  );
};

export default LoginModal;
