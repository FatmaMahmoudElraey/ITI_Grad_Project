import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faFacebookF,
  faTwitter,
  faInstagram,
  faYoutube,
  faPinterest
} from '@fortawesome/free-brands-svg-icons';

const Footer = () => {
  return (
    <footer className="footer mt-5 py-5">
      <Container>
        <Row className="mb-4">
          <Col md={6} lg={3} className="mb-4 mb-lg-0">
            <h5 className="text-white mb-4">Envato Marketplace</h5>
            <p className="text-muted">
              The world's leading marketplace for digital assets and creative tools.
            </p>
            <div className="social-icons">
              <a href="#" className="me-2 text-white">
                <FontAwesomeIcon icon={faFacebookF} />
              </a>
              <a href="#" className="me-2 text-white">
                <FontAwesomeIcon icon={faTwitter} />
              </a>
              <a href="#" className="me-2 text-white">
                <FontAwesomeIcon icon={faInstagram} />
              </a>
              <a href="#" className="me-2 text-white">
                <FontAwesomeIcon icon={faYoutube} />
              </a>
              <a href="#" className="text-white">
                <FontAwesomeIcon icon={faPinterest} />
              </a>
            </div>
          </Col>
          <Col md={6} lg={3} className="mb-4 mb-lg-0">
            <h5 className="text-white mb-4">Categories</h5>
            <ul className="list-unstyled footer-links">
              <li className="mb-2">
                <Link to="/category/wordpress" className="text-muted">WordPress Themes</Link>
              </li>
              <li className="mb-2">
                <Link to="/category/html" className="text-muted">HTML Templates</Link>
              </li>
              <li className="mb-2">
                <Link to="/category/graphics" className="text-muted">Graphics</Link>
              </li>
              <li className="mb-2">
                <Link to="/category/photos" className="text-muted">Stock Photos</Link>
              </li>
              <li className="mb-2">
                <Link to="/category/video" className="text-muted">Video Templates</Link>
              </li>
              <li>
                <Link to="/category/audio" className="text-muted">Audio</Link>
              </li>
            </ul>
          </Col>
          <Col md={6} lg={3} className="mb-4 mb-lg-0">
            <h5 className="text-white mb-4">Company</h5>
            <ul className="list-unstyled footer-links">
              <li className="mb-2">
                <Link to="/about" className="text-muted">About Us</Link>
              </li>
              <li className="mb-2">
                <Link to="/careers" className="text-muted">Careers</Link>
              </li>
              <li className="mb-2">
                <Link to="/blog" className="text-muted">Blog</Link>
              </li>
              <li className="mb-2">
                <Link to="/help" className="text-muted">Help & Support</Link>
              </li>
              <li className="mb-2">
                <Link to="/privacy" className="text-muted">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/terms" className="text-muted">Terms of Service</Link>
              </li>
            </ul>
          </Col>
          <Col md={6} lg={3}>
            <h5 className="text-white mb-4">Newsletter</h5>
            <p className="text-muted mb-3">
              Subscribe to get the latest news and updates.
            </p>
            <Form className="footer-subscribe-form">
              <Form.Group className="mb-3">
                <Form.Control
                  type="email"
                  placeholder="Your email address"
                  className="bg-dark border-secondary text-white"
                />
              </Form.Group>
              <Button variant="envato" className="w-100">
                Subscribe
              </Button>
            </Form>
          </Col>
        </Row>
        <hr className="border-gray my-4" />
        <Row>
          <Col className="text-center text-muted">
            <p className="mb-0">
              &copy; {new Date().getFullYear()} Envato Marketplace. All rights reserved.
            </p>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;
