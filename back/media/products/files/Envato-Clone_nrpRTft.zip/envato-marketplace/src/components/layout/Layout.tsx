import type React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import AppModals from '../common/AppModals';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="d-flex flex-column min-vh-100">
      <Navbar />
      <main className="flex-grow-1">
        {children}
      </main>
      <Footer />
      <AppModals />
    </div>
  );
};

export default Layout;
