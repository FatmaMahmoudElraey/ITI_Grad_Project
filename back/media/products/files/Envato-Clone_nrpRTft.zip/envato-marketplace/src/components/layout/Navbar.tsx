import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Navbar as BsNavbar, Container, Nav, NavDropdown, Button, Form, FormControl } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faShoppingCart, faUser, faBars } from '@fortawesome/free-solid-svg-icons';
import { useSelector, useDispatch } from 'react-redux';
import type { RootState } from '../../redux/store';
import { toggleSearch, openModal } from '../../redux/reducers/uiSlice';

const Navbar = () => {
  const dispatch = useDispatch();
  const [expanded, setExpanded] = useState(false);
  const { isAuthenticated, user } = useSelector((state: RootState) => state.auth);
  const { totalItems } = useSelector((state: RootState) => state.cart);

  const handleSearchClick = () => {
    dispatch(toggleSearch());
  };

  const handleLoginClick = () => {
    dispatch(openModal({ type: 'login' }));
  };

  const handleRegisterClick = () => {
    dispatch(openModal({ type: 'register' }));
  };

  const handleCartClick = () => {
    dispatch(openModal({ type: 'cart' }));
  };

  return (
    <BsNavbar
      bg="dark"
      variant="dark"
      expand="lg"
      className="navbar-envato sticky-top"
      expanded={expanded}
    >
      <Container>
        <BsNavbar.Brand as={Link} to="/">
          <strong>Envato</strong>Marketplace
        </BsNavbar.Brand>
        <BsNavbar.Toggle
          aria-controls="basic-navbar-nav"
          onClick={() => setExpanded(!expanded)}
        >
          <FontAwesomeIcon icon={faBars} />
        </BsNavbar.Toggle>
        <BsNavbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <NavDropdown title="Categories" id="categories-dropdown">
              <NavDropdown.Item as={Link} to="/category/wordpress">WordPress Themes</NavDropdown.Item>
              <NavDropdown.Item as={Link} to="/category/html">HTML Templates</NavDropdown.Item>
              <NavDropdown.Item as={Link} to="/category/graphics">Graphics</NavDropdown.Item>
              <NavDropdown.Item as={Link} to="/category/photos">Stock Photos</NavDropdown.Item>
              <NavDropdown.Item as={Link} to="/category/video">Video Templates</NavDropdown.Item>
              <NavDropdown.Item as={Link} to="/category/audio">Audio</NavDropdown.Item>
            </NavDropdown>
            <Nav.Link as={Link} to="/featured">Featured</Nav.Link>
            <Nav.Link as={Link} to="/popular">Popular</Nav.Link>
            <Nav.Link as={Link} to="/new">New Items</Nav.Link>
          </Nav>
          <Form className="d-flex mx-auto">
            <div className="position-relative search-form">
              <FormControl
                type="search"
                placeholder="Search items..."
                className="me-2"
                aria-label="Search"
              />
              <Button
                variant="outline-success"
                className="position-absolute end-0 top-0 h-100 d-flex align-items-center"
                onClick={handleSearchClick}
              >
                <FontAwesomeIcon icon={faSearch} />
              </Button>
            </div>
          </Form>
          <Nav>
            <Button
              variant="link"
              className="nav-link position-relative"
              onClick={handleCartClick}
            >
              <FontAwesomeIcon icon={faShoppingCart} />
              {totalItems > 0 && (
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-envato">
                  {totalItems}
                </span>
              )}
            </Button>
            {isAuthenticated ? (
              <NavDropdown
                title={
                  <span>
                    <FontAwesomeIcon icon={faUser} className="me-1" />
                    {user?.name}
                  </span>
                }
                id="user-dropdown"
              >
                <NavDropdown.Item as={Link} to="/dashboard">Dashboard</NavDropdown.Item>
                <NavDropdown.Item as={Link} to="/profile">Profile</NavDropdown.Item>
                <NavDropdown.Item as={Link} to="/purchases">Purchases</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item as={Link} to="/logout">Logout</NavDropdown.Item>
              </NavDropdown>
            ) : (
              <>
                <Button
                  variant="outline-light"
                  className="me-2"
                  onClick={handleLoginClick}
                >
                  Sign In
                </Button>
                <Button
                  variant="envato"
                  onClick={handleRegisterClick}
                >
                  Create Account
                </Button>
              </>
            )}
          </Nav>
        </BsNavbar.Collapse>
      </Container>
    </BsNavbar>
  );
};

export default Navbar;
