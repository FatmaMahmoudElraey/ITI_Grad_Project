import { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Button, Form, InputGroup, Dropdown } from 'react-bootstrap';
import { useParams, Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faFilter, faStar, faTag } from '@fortawesome/free-solid-svg-icons';
import type { RootState } from '../../redux/store';
import { setSelectedCategory } from '../../redux/reducers/productsSlice';

// Category titles mapping
const categoryTitles: { [key: string]: string } = {
  wordpress: 'WordPress Themes',
  html: 'HTML Templates',
  graphics: 'Graphics',
  photos: 'Stock Photos',
  video: 'Video Templates',
  audio: 'Audio',
};

const CategoryPage = () => {
  const { category } = useParams<{ category: string }>();
  const dispatch = useDispatch();
  const { items, filteredItems, loading } = useSelector((state: RootState) => state.products);
  const [sortBy, setSortBy] = useState('popular');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100]);
  const [displayItems, setDisplayItems] = useState<typeof filteredItems>([]);

  useEffect(() => {
    if (category) {
      dispatch(setSelectedCategory(category));
    }

    return () => {
      // Clear filter when component unmounts
      dispatch(setSelectedCategory(null));
    };
  }, [category, dispatch]);

  useEffect(() => {
    // Apply sorting
    let sortedItems = [...filteredItems];

    switch (sortBy) {
      case 'popular':
        sortedItems.sort((a, b) => b.sales - a.sales);
        break;
      case 'newest':
        sortedItems.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'price_low':
        sortedItems.sort((a, b) => a.price - b.price);
        break;
      case 'price_high':
        sortedItems.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        sortedItems.sort((a, b) => b.rating - a.rating);
        break;
      default:
        break;
    }

    // Apply price filter
    sortedItems = sortedItems.filter(
      item => item.price >= priceRange[0] && item.price <= priceRange[1]
    );

    setDisplayItems(sortedItems);
  }, [filteredItems, sortBy, priceRange]);

  const handleSortChange = (value: string) => {
    setSortBy(value);
  };

  const handlePriceChange = (type: 'min' | 'max', value: string) => {
    const numValue = Number.parseInt(value, 10);

    if (type === 'min') {
      setPriceRange([numValue, priceRange[1]]);
    } else {
      setPriceRange([priceRange[0], numValue]);
    }
  };

  if (!category) {
    return (
      <Container className="py-5 text-center">
        <h2>Category not found</h2>
        <p>The category you are looking for does not exist or has been removed.</p>
        <Link to="/" className="btn btn-envato">
          Return to Home
        </Link>
      </Container>
    );
  }

  return (
    <Container className="py-5">
      <div className="mb-4">
        <h1>{categoryTitles[category] || 'Products'}</h1>
        <p className="text-muted">Browse our collection of {categoryTitles[category] || 'products'}</p>
      </div>

      <Row className="mb-4">
        <Col md={8}>
          <InputGroup>
            <Form.Control
              placeholder={`Search in ${categoryTitles[category] || 'products'}...`}
              aria-label="Search"
            />
            <Button variant="envato">
              <FontAwesomeIcon icon={faSearch} />
            </Button>
          </InputGroup>
        </Col>
        <Col md={4}>
          <div className="d-flex justify-content-end">
            <Dropdown className="me-2">
              <Dropdown.Toggle variant="outline-secondary" id="sort-dropdown">
                <FontAwesomeIcon icon={faFilter} className="me-1" />
                Sort: {sortBy.charAt(0).toUpperCase() + sortBy.slice(1).replace('_', ' ')}
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item active={sortBy === 'popular'} onClick={() => handleSortChange('popular')}>
                  Most Popular
                </Dropdown.Item>
                <Dropdown.Item active={sortBy === 'newest'} onClick={() => handleSortChange('newest')}>
                  Newest Items
                </Dropdown.Item>
                <Dropdown.Item active={sortBy === 'price_low'} onClick={() => handleSortChange('price_low')}>
                  Price: Low to High
                </Dropdown.Item>
                <Dropdown.Item active={sortBy === 'price_high'} onClick={() => handleSortChange('price_high')}>
                  Price: High to Low
                </Dropdown.Item>
                <Dropdown.Item active={sortBy === 'rating'} onClick={() => handleSortChange('rating')}>
                  Top Rated
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </Col>
      </Row>

      <Row>
        <Col lg={3} className="mb-4">
          <Card className="border-0 shadow-sm">
            <Card.Header className="bg-light">
              <h5 className="mb-0">Filter</h5>
            </Card.Header>
            <Card.Body>
              <h6 className="mb-3">Price Range</h6>
              <div className="mb-3">
                <Form.Label>Min Price ($)</Form.Label>
                <Form.Control
                  type="number"
                  min="0"
                  value={priceRange[0]}
                  onChange={(e) => handlePriceChange('min', e.target.value)}
                />
              </div>
              <div className="mb-4">
                <Form.Label>Max Price ($)</Form.Label>
                <Form.Control
                  type="number"
                  min="0"
                  value={priceRange[1]}
                  onChange={(e) => handlePriceChange('max', e.target.value)}
                />
              </div>

              <h6 className="mb-3">Rating</h6>
              <div className="mb-4">
                {[5, 4, 3, 2, 1].map((rating) => (
                  <div key={`rating-${rating}`} className="mb-2">
                    <Form.Check
                      type="checkbox"
                      id={`rating-${rating}`}
                      label={
                        <span>
                          {[...Array(rating)].map((_, i) => (
                            <FontAwesomeIcon
                              key={`star-${rating}-${i}`}
                              icon={faStar}
                              className="text-warning me-1"
                            />
                          ))}
                          {[...Array(5 - rating)].map((_, i) => (
                            <FontAwesomeIcon
                              key={`empty-star-${rating}-${i}`}
                              icon={faStar}
                              className="text-muted me-1"
                            />
                          ))}
                          & Above
                        </span>
                      }
                    />
                  </div>
                ))}
              </div>

              <Button variant="envato" className="w-100">
                Apply Filters
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={9}>
          {loading ? (
            <div className="text-center py-5">
              <div className="spinner-border text-envato" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
              <p className="mt-3">Loading products...</p>
            </div>
          ) : displayItems.length > 0 ? (
            <Row>
              {displayItems.map((product) => (
                <Col md={6} lg={4} key={product.id} className="mb-4">
                  <Card className="h-100 card-hover">
                    <Card.Img
                      variant="top"
                      src={product.image}
                      alt={product.title}
                      style={{ height: '200px', objectFit: 'cover' }}
                    />
                    <Card.Body>
                      <Card.Title as="h5" className="mb-2">
                        <Link to={`/product/${product.id}`} className="text-decoration-none text-dark">
                          {product.title}
                        </Link>
                      </Card.Title>
                      <Card.Text className="text-muted small mb-2">
                        by <Link to={`/author/${product.author.id}`} className="text-decoration-none">{product.author.name}</Link>
                      </Card.Text>
                      <div className="d-flex small mb-2">
                        {[...Array(5)].map((_, i) => (
                          <FontAwesomeIcon
                            key={`product-rating-${product.id}-${i}`}
                            icon={faStar}
                            className={i < Math.floor(product.rating) ? 'text-warning' : 'text-muted'}
                          />
                        ))}
                        <span className="ms-1 text-muted">({Math.floor(product.sales / 10)})</span>
                      </div>
                      <div className="d-flex justify-content-between align-items-center mt-3">
                        <span className="fw-bold">${product.price}</span>
                        <Button variant="outline-envato" size="sm">
                          <FontAwesomeIcon icon={faTag} className="me-1" />
                          Add to Cart
                        </Button>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          ) : (
            <div className="text-center py-5">
              <h3>No products found</h3>
              <p>Try adjusting your filters or search criteria.</p>
            </div>
          )}
        </Col>
      </Row>
    </Container>
  );
};

export default CategoryPage;
