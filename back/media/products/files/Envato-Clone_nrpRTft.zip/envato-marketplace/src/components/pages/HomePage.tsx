import { useEffect } from 'react';
import { Container, Row, Col, Card, Button, FormControl, InputGroup } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import { useDispatch, useSelector } from 'react-redux';
import type { RootState } from '../../redux/store';
import { fetchProducts } from '../../redux/reducers/productsSlice';
import { Link } from 'react-router-dom';

// These would come from API in real app
const categories = [
  { id: 'wordpress', name: 'WordPress Themes', count: 10845 },
  { id: 'html', name: 'HTML Templates', count: 7652 },
  { id: 'graphics', name: 'Graphics', count: 15489 },
  { id: 'photos', name: 'Stock Photos', count: 25784 },
  { id: 'video', name: 'Video Templates', count: 4521 },
  { id: 'audio', name: 'Audio', count: 9852 },
];

// Sample images (in a real app these would come from backend)
const categoryImages: { [key: string]: string } = {
  wordpress: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
  html: 'https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
  graphics: 'https://images.unsplash.com/photo-1558655146-d09347e92766?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
  photos: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
  video: 'https://images.unsplash.com/photo-1535016120720-40c646be5580?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
  audio: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
};

// Sample featured products (in a real app these would come from API)
const sampleProducts = [
  {
    id: '1',
    title: 'Avada - Responsive Multi-Purpose Theme',
    description: 'The #1 selling theme of all time on ThemeForest',
    price: 60,
    image: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
    category: 'wordpress',
    author: {
      id: 'auth1',
      name: 'ThemeFusion',
    },
    rating: 4.8,
    sales: 658945,
    createdAt: '2023-01-15',
  },
  {
    id: '2',
    title: 'BeTheme - Responsive Multi-Purpose WordPress Theme',
    description: 'Responsive, multi-purpose WordPress theme with 650+ pre-built websites',
    price: 59,
    image: 'https://images.unsplash.com/photo-1493119508027-2b584f234d6c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
    category: 'wordpress',
    author: {
      id: 'auth2',
      name: 'Muffin Group',
    },
    rating: 4.7,
    sales: 245698,
    createdAt: '2023-02-10',
  },
  {
    id: '3',
    title: 'Corporate Business HTML Template',
    description: 'Modern HTML template for corporate and business websites',
    price: 24,
    image: 'https://images.unsplash.com/photo-1496346236646-50e985b31ea4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
    category: 'html',
    author: {
      id: 'auth3',
      name: 'CodePixar',
    },
    rating: 4.5,
    sales: 12456,
    createdAt: '2023-03-15',
  },
  {
    id: '4',
    title: 'Cinematic Color Presets',
    description: 'Professional Adobe Premiere Pro color grading presets',
    price: 19,
    image: 'https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
    category: 'video',
    author: {
      id: 'auth4',
      name: 'MotionArray',
    },
    rating: 4.9,
    sales: 8932,
    createdAt: '2023-04-05',
  },
  {
    id: '5',
    title: 'Epic Orchestral Music Pack',
    description: 'Powerful orchestral tracks for your projects',
    price: 29,
    image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
    category: 'audio',
    author: {
      id: 'auth5',
      name: 'AudioJungle',
    },
    rating: 4.6,
    sales: 6524,
    createdAt: '2023-05-12',
  },
  {
    id: '6',
    title: 'Business Infographic Pack',
    description: '50+ business infographic templates',
    price: 18,
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80',
    category: 'graphics',
    author: {
      id: 'auth6',
      name: 'GraphicRiver',
    },
    rating: 4.7,
    sales: 15689,
    createdAt: '2023-06-18',
  },
];

const HomePage = () => {
  const dispatch = useDispatch();
  const { featuredItems, popularItems, loading } = useSelector(
    (state: RootState) => state.products,
  );

  useEffect(() => {
    if (featuredItems.length === 0) {
      // Simulate API fetch
      dispatch({ type: 'products/setProducts', payload: sampleProducts });

      // In a real app, we would use:
      // dispatch(fetchProducts());
    }
  }, [dispatch, featuredItems.length]);

  return (
    <div>
      {/* Hero Section */}
      <section className="hero-section">
        <Container>
          <Row className="py-5 align-items-center">
            <Col md={7} className="text-center text-md-start mb-4 mb-md-0">
              <h1 className="display-4 fw-bold mb-3">Find the perfect digital assets</h1>
              <p className="lead mb-4">
                Explore thousands of high-quality digital products created by world-class designers, developers, photographers, and creators.
              </p>
              <InputGroup className="mb-3 hero-search">
                <FormControl
                  placeholder="Search for items..."
                  aria-label="Search for items"
                  size="lg"
                />
                <Button variant="envato" size="lg">
                  <FontAwesomeIcon icon={faSearch} />
                </Button>
              </InputGroup>
            </Col>
            <Col md={5}>
              <img
                src="https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&q=80"
                alt="Envato Marketplace"
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
        </Container>
      </section>

      {/* Category Section */}
      <section className="py-5">
        <Container>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h2 className="mb-0">Browse Categories</h2>
            <Link to="/categories" className="text-decoration-none">
              View all <FontAwesomeIcon icon={faArrowRight} />
            </Link>
          </div>

          <Row>
            {categories.map((category) => (
              <Col sm={6} md={4} xl={2} key={category.id} className="mb-4">
                <Link
                  to={`/category/${category.id}`}
                  className="text-decoration-none text-dark"
                >
                  <Card className="category-card h-100 card-hover transition">
                    <Card.Img
                      variant="top"
                      src={categoryImages[category.id]}
                      alt={category.name}
                      style={{ height: '140px', objectFit: 'cover' }}
                    />
                    <Card.Body className="text-center">
                      <Card.Title className="h6 mb-2">{category.name}</Card.Title>
                      <small className="text-muted">{category.count.toLocaleString()} items</small>
                    </Card.Body>
                  </Card>
                </Link>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Featured Items Section */}
      <section className="py-5 bg-light">
        <Container>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h2 className="mb-0">Featured Items</h2>
            <Link to="/featured" className="text-decoration-none">
              View all <FontAwesomeIcon icon={faArrowRight} />
            </Link>
          </div>

          <Row>
            {sampleProducts.map((product) => (
              <Col md={6} lg={4} key={product.id} className="mb-4">
                <Card className="h-100 card-hover">
                  <div className="position-relative">
                    <Card.Img
                      variant="top"
                      src={product.image}
                      alt={product.title}
                      style={{ height: '200px', objectFit: 'cover' }}
                    />
                  </div>
                  <Card.Body>
                    <Card.Title as="h5" className="mb-2">
                      <Link to={`/product/${product.id}`} className="text-decoration-none text-dark">
                        {product.title}
                      </Link>
                    </Card.Title>
                    <Card.Text className="text-muted small mb-2">
                      by <Link to={`/author/${product.author.id}`} className="text-decoration-none">{product.author.name}</Link>
                    </Card.Text>
                    <div className="d-flex justify-content-between align-items-center mt-3">
                      <span className="fw-bold">${product.price}</span>
                      <Button variant="outline-envato" size="sm">Add to Cart</Button>
                    </div>
                  </Card.Body>
                  <Card.Footer className="bg-white border-top-0">
                    <small className="text-muted">
                      <span className="me-3">
                        <i className="bi bi-star-fill text-warning me-1"></i>
                        {product.rating}
                      </span>
                      <span>{product.sales.toLocaleString()} sales</span>
                    </small>
                  </Card.Footer>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Call to Action */}
      <section className="py-5 bg-envato-dark text-white text-center">
        <Container>
          <h2 className="mb-4">Start selling on Envato Marketplace</h2>
          <p className="lead mb-4">
            Join thousands of creators and start earning money from your digital products.
          </p>
          <Button variant="light" size="lg">
            Become an Author
          </Button>
        </Container>
      </section>
    </div>
  );
};

export default HomePage;
