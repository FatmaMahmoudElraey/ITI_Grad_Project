import { useEffect } from 'react';
import { Container, Row, Col, Button, Badge, Tabs, Tab, Card } from 'react-bootstrap';
import { useParams, Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar, faShoppingCart, faEye, faHeart, faShield, faDownload } from '@fortawesome/free-solid-svg-icons';
import type { RootState } from '../../redux/store';
import { addToCart } from '../../redux/reducers/cartSlice';
import { setSelectedProduct } from '../../redux/reducers/productsSlice';

const ProductDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const dispatch = useDispatch();
  const { items, selectedProduct } = useSelector((state: RootState) => state.products);

  useEffect(() => {
    if (id) {
      const product = items.find(item => item.id === id);
      if (product) {
        dispatch(setSelectedProduct(product));
      }
    }

    return () => {
      // Clean up when component unmounts
      dispatch(setSelectedProduct(null));
    };
  }, [id, items, dispatch]);

  const handleAddToCart = () => {
    if (selectedProduct) {
      dispatch(
        addToCart({
          id: selectedProduct.id,
          title: selectedProduct.title,
          price: selectedProduct.price,
          image: selectedProduct.image,
          quantity: 1,
          author: selectedProduct.author.name,
        }),
      );
    }
  };

  if (!selectedProduct) {
    return (
      <Container className="py-5 text-center">
        <h2>Product not found</h2>
        <p>The product you are looking for does not exist or has been removed.</p>
        <Link to="/" className="btn btn-envato">
          Return to Home
        </Link>
      </Container>
    );
  }

  return (
    <Container className="py-5">
      <Row>
        <Col lg={8}>
          <div className="product-image-container mb-4">
            <img
              src={selectedProduct.image}
              alt={selectedProduct.title}
              className="img-fluid rounded shadow-sm"
              style={{ maxHeight: '500px', width: '100%', objectFit: 'cover' }}
            />
          </div>

          <Tabs defaultActiveKey="description" id="product-tabs" className="mb-4">
            <Tab eventKey="description" title="Description">
              <div className="p-4 bg-white rounded shadow-sm">
                <h4>Description</h4>
                <p>{selectedProduct.description}</p>

                <h5 className="mt-4">Features</h5>
                <ul>
                  <li>High-quality, responsive design</li>
                  <li>Easy to customize and extend</li>
                  <li>Comprehensive documentation</li>
                  <li>Regular updates and support</li>
                </ul>
              </div>
            </Tab>
            <Tab eventKey="reviews" title="Reviews">
              <div className="p-4 bg-white rounded shadow-sm">
                <h4>Customer Reviews</h4>
                <div className="d-flex align-items-center mb-4">
                  <div className="display-4 me-3">{selectedProduct.rating}</div>
                  <div>
                    <div className="text-warning mb-1">
                      {[...Array(5)].map((_, i) => (
                        <FontAwesomeIcon
                          key={i}
                          icon={faStar}
                          className={i < Math.floor(selectedProduct.rating) ? 'text-warning' : 'text-muted'}
                        />
                      ))}
                    </div>
                    <p className="mb-0">Based on {Math.floor(selectedProduct.sales / 10)} reviews</p>
                  </div>
                </div>

                {/* Sample reviews */}
                <Card className="mb-3">
                  <Card.Body>
                    <div className="d-flex justify-content-between mb-2">
                      <h6 className="mb-0">John Doe</h6>
                      <div className="text-warning">
                        {[...Array(5)].map((_, i) => (
                          <FontAwesomeIcon key={i} icon={faStar} className={i < 5 ? 'text-warning' : 'text-muted'} />
                        ))}
                      </div>
                    </div>
                    <p className="text-muted small mb-2">2 months ago</p>
                    <p>Great product! Easy to use and customize. The support team is also very responsive.</p>
                  </Card.Body>
                </Card>

                <Card className="mb-3">
                  <Card.Body>
                    <div className="d-flex justify-content-between mb-2">
                      <h6 className="mb-0">Jane Smith</h6>
                      <div className="text-warning">
                        {[...Array(5)].map((_, i) => (
                          <FontAwesomeIcon key={i} icon={faStar} className={i < 4 ? 'text-warning' : 'text-muted'} />
                        ))}
                      </div>
                    </div>
                    <p className="text-muted small mb-2">1 month ago</p>
                    <p>Good product overall. Documentation could be better though.</p>
                  </Card.Body>
                </Card>
              </div>
            </Tab>
            <Tab eventKey="support" title="Support">
              <div className="p-4 bg-white rounded shadow-sm">
                <h4>Support</h4>
                <p>
                  Our team is here to help you with any questions or issues you may have with this product.
                </p>
                <h5 className="mt-4">Support Includes:</h5>
                <ul>
                  <li>6 months of support from {selectedProduct.author.name}</li>
                  <li>Response within 24 hours</li>
                  <li>Bug fixes and updates</li>
                </ul>
                <Button variant="outline-envato" className="mt-3">
                  Contact Support
                </Button>
              </div>
            </Tab>
          </Tabs>
        </Col>

        <Col lg={4}>
          <div className="sticky-top" style={{ top: '100px' }}>
            <Card className="mb-4">
              <Card.Body>
                <h2 className="mb-3">{selectedProduct.title}</h2>
                <p className="text-muted mb-4">{selectedProduct.description}</p>

                <div className="d-flex justify-content-between align-items-center mb-4">
                  <span className="fs-3 fw-bold">${selectedProduct.price}</span>
                  <Badge bg="success" className="px-3 py-2">
                    {selectedProduct.sales.toLocaleString()} Sales
                  </Badge>
                </div>

                <div className="mb-4">
                  <Button
                    variant="envato"
                    className="w-100 py-2 mb-2"
                    onClick={handleAddToCart}
                  >
                    <FontAwesomeIcon icon={faShoppingCart} className="me-2" />
                    Add to Cart
                  </Button>
                  <div className="d-flex mt-3">
                    <Button variant="outline-secondary" className="flex-grow-1 me-2">
                      <FontAwesomeIcon icon={faEye} className="me-1" /> Demo
                    </Button>
                    <Button variant="outline-secondary" className="flex-grow-1">
                      <FontAwesomeIcon icon={faHeart} className="me-1" /> Favorite
                    </Button>
                  </div>
                </div>

                <div className="mb-4">
                  <h6>Item Details</h6>
                  <div className="d-flex justify-content-between mb-2">
                    <span className="text-muted">Author:</span>
                    <Link to={`/author/${selectedProduct.author.id}`}>
                      {selectedProduct.author.name}
                    </Link>
                  </div>
                  <div className="d-flex justify-content-between mb-2">
                    <span className="text-muted">Category:</span>
                    <Link to={`/category/${selectedProduct.category}`}>
                      {selectedProduct.category.charAt(0).toUpperCase() + selectedProduct.category.slice(1)}
                    </Link>
                  </div>
                  <div className="d-flex justify-content-between mb-2">
                    <span className="text-muted">Released:</span>
                    <span>{new Date(selectedProduct.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="d-flex justify-content-between">
                    <span className="text-muted">Last Update:</span>
                    <span>{new Date().toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="bg-light p-3 rounded mb-3">
                  <div className="d-flex align-items-center mb-3">
                    <FontAwesomeIcon icon={faShield} className="text-success me-2" />
                    <div>
                      <h6 className="mb-0">6 Months Support</h6>
                      <small className="text-muted">From {selectedProduct.author.name}</small>
                    </div>
                  </div>
                  <div className="d-flex align-items-center">
                    <FontAwesomeIcon icon={faDownload} className="text-success me-2" />
                    <div>
                      <h6 className="mb-0">Future Updates</h6>
                      <small className="text-muted">Free access to all future updates</small>
                    </div>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </div>
        </Col>
      </Row>

      {/* Similar Items */}
      <section className="mt-5">
        <h3 className="mb-4">You Might Also Like</h3>
        <Row>
          {items
            .filter(
              (item) =>
                item.category === selectedProduct.category &&
                item.id !== selectedProduct.id
            )
            .slice(0, 3)
            .map((product) => (
              <Col md={4} key={product.id} className="mb-4">
                <Card className="h-100 card-hover">
                  <Card.Img
                    variant="top"
                    src={product.image}
                    alt={product.title}
                    style={{ height: '200px', objectFit: 'cover' }}
                  />
                  <Card.Body>
                    <Card.Title as="h5" className="mb-2">
                      <Link to={`/product/${product.id}`} className="text-decoration-none text-dark">
                        {product.title}
                      </Link>
                    </Card.Title>
                    <Card.Text className="text-muted small mb-2">
                      by <Link to={`/author/${product.author.id}`} className="text-decoration-none">{product.author.name}</Link>
                    </Card.Text>
                    <div className="d-flex justify-content-between align-items-center mt-3">
                      <span className="fw-bold">${product.price}</span>
                      <Button variant="outline-envato" size="sm">
                        Add to Cart
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
        </Row>
      </section>
    </Container>
  );
};

export default ProductDetailsPage;
