import { createSlice, type PayloadAction, createAsyncThunk } from '@reduxjs/toolkit';

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  image: string;
  category: string;
  author: {
    id: string;
    name: string;
    avatar?: string;
  };
  rating: number;
  sales: number;
  createdAt: string;
}

interface ProductsState {
  items: Product[];
  filteredItems: Product[];
  featuredItems: Product[];
  popularItems: Product[];
  newItems: Product[];
  selectedCategory: string | null;
  searchQuery: string;
  selectedProduct: Product | null;
  loading: boolean;
  error: string | null;
}

const initialState: ProductsState = {
  items: [],
  filteredItems: [],
  featuredItems: [],
  popularItems: [],
  newItems: [],
  selectedCategory: null,
  searchQuery: '',
  selectedProduct: null,
  loading: false,
  error: null,
};

// Mock data fetch (in a real app, this would be API calls)
export const fetchProducts = createAsyncThunk(
  'products/fetchProducts',
  async () => {
    return new Promise<Product[]>((resolve) => {
      // Simulate API delay
      setTimeout(() => {
        resolve([]); // In a real app, this would be API data
      }, 500);
    });
  },
);

const productsSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    setProducts: (state, action: PayloadAction<Product[]>) => {
      state.items = action.payload;
      state.filteredItems = action.payload;
    },
    setSelectedCategory: (state, action: PayloadAction<string | null>) => {
      state.selectedCategory = action.payload;

      if (action.payload) {
        state.filteredItems = state.items.filter(
          item => item.category === action.payload
        );
      } else {
        state.filteredItems = state.items;
      }
    },
    setSearchQuery: (state, action: PayloadAction<string>) => {
      state.searchQuery = action.payload;

      if (action.payload) {
        const query = action.payload.toLowerCase();
        state.filteredItems = state.items.filter(
          item =>
            item.title.toLowerCase().includes(query) ||
            item.description.toLowerCase().includes(query)
        );
      } else {
        state.filteredItems = state.items;
      }

      // Apply category filter if already selected
      if (state.selectedCategory) {
        state.filteredItems = state.filteredItems.filter(
          item => item.category === state.selectedCategory
        );
      }
    },
    setSelectedProduct: (state, action: PayloadAction<Product | null>) => {
      state.selectedProduct = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProducts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
        state.filteredItems = action.payload;

        // Set featured, popular and new items
        state.featuredItems = [...action.payload].sort(() => Math.random() - 0.5).slice(0, 6);
        state.popularItems = [...action.payload].sort((a, b) => b.sales - a.sales).slice(0, 8);
        state.newItems = [...action.payload]
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 8);
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch products';
      });
  },
});

export const {
  setProducts,
  setSelectedCategory,
  setSearchQuery,
  setSelectedProduct
} = productsSlice.actions;

export default productsSlice.reducer;
