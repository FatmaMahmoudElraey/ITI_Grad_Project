import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

interface Modal {
  isOpen: boolean;
  type: 'login' | 'register' | 'cart' | 'productDetails' | null;
  data?: any;
}

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
}

interface UiState {
  sidebarOpen: boolean;
  modal: Modal;
  toasts: ToastMessage[];
  isSearchOpen: boolean;
  isDarkMode: boolean;
}

const initialState: UiState = {
  sidebarOpen: false,
  modal: {
    isOpen: false,
    type: null,
  },
  toasts: [],
  isSearchOpen: false,
  isDarkMode: false,
};

const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    toggleSidebar: (state) => {
      state.sidebarOpen = !state.sidebarOpen;
    },
    openModal: (state, action: PayloadAction<{ type: Modal['type']; data?: any }>) => {
      state.modal = {
        isOpen: true,
        type: action.payload.type,
        data: action.payload.data,
      };
    },
    closeModal: (state) => {
      state.modal = {
        isOpen: false,
        type: null,
      };
    },
    addToast: (state, action: PayloadAction<Omit<ToastMessage, 'id'>>) => {
      const id = Date.now().toString();
      state.toasts.push({
        id,
        ...action.payload,
      });
    },
    removeToast: (state, action: PayloadAction<string>) => {
      state.toasts = state.toasts.filter((toast) => toast.id !== action.payload);
    },
    toggleSearch: (state) => {
      state.isSearchOpen = !state.isSearchOpen;
    },
    toggleDarkMode: (state) => {
      state.isDarkMode = !state.isDarkMode;
    },
  },
});

export const {
  toggleSidebar,
  openModal,
  closeModal,
  addToast,
  removeToast,
  toggleSearch,
  toggleDarkMode,
} = uiSlice.actions;

export default uiSlice.reducer;
