import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../reducers/authSlice';
import cartReducer from '../reducers/cartSlice';
import productsReducer from '../reducers/productsSlice';
import uiReducer from '../reducers/uiSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    cart: cartReducer,
    products: productsReducer,
    ui: uiReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
